# ARCHRUUD App Launcher — v1.0.2 test

## Changed
- Bottom-center edge opens the launcher on a normal left click, not on hover or a held-button drag.
- Invisible edge target height increased from 2 to 8 pixels to make clicking practical.
- On-screen help text and documentation updated.

## Unchanged
- `SUPER+A` Lua shortcut and IPC behavior.
- Launcher design, program list, icon layout, navigation, auto-close timer and wallpaper coordination.
- Installer's backup behavior and existing file locations.

## Testing
- Verify ordinary hover does not open the launcher.
- Verify a left click on the bottom-center edge opens it.
- Verify `SUPER+A` still works.
- If edge clicking is inconvenient, keep using `SUPER+A` and remove the edge trigger in a later version.
