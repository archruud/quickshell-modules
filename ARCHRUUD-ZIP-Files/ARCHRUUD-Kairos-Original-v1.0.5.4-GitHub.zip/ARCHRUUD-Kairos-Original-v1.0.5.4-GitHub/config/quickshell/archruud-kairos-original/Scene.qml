// Kairos: one dynamic island on the top edge, carrying the clock. The window
// holds the open island whole, masks input to the island, and reserves only the
// resting band, so tiled windows clear the pill without the surface ever
// resizing during the morph. While the now-playing panel is pinned open the
// window covers the screen and a click anywhere off the panel dismisses it.

pragma ComponentBehavior: Bound

import QtQuick
import Quickshell
import Quickshell.Wayland
import "services"
import "components" as C
import "settings" as S

Scope {
    id: scene
    property bool powerCompanionOpen: false

    // The screen, set by Frame's per-monitor Loader.
    required property var modelData

    // The gear and the quick-settings button each own one window; only one opens.
    property bool settingsOpen: false
    property bool quickOpen: false
    function toggleSettings() {
        scene.settingsOpen = !scene.settingsOpen;
        if (scene.settingsOpen) scene.quickOpen = false;
    }
    function toggleQuickSettings() {
        scene.quickOpen = !scene.quickOpen;
        if (scene.quickOpen) scene.settingsOpen = false;
    }

    PanelWindow {
        id: win

        screen: scene.modelData

        // This screen's shell state: while Super+Space has the launcher open, the
        // launcher's own pill stands in for this island, and this one drops back to
        // its resting size underneath it.
        readonly property var state: null

        color: "transparent"
        exclusionMode: ExclusionMode.Normal
        // Reserve the resting band so tiled windows clear the island. The open
        // island overhangs it, which is the point of a floating one.
        exclusiveZone: island.band
        WlrLayershell.layer: WlrLayer.Top
        WlrLayershell.keyboardFocus: island.quickOpen
            ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
        WlrLayershell.namespace: "archruud-kairos-original"

        // Rests as tall as the island's tallest state so the surface never
        // resizes: the pill is what grows.
        anchors { top: true; left: true; right: true }
        implicitHeight: island.reach

        // Only the island takes input; the strip around it passes clicks through.
        mask: Region {
            x: island.x
            y: island.y
            width: island.width
            height: island.height
        }

        C.Island {
            id: island
            y: island.topGap
            // The clock's resting centre lands on the screen's centre line, so the
            // clock rests centred and expands there; the music grows leftward from
            // just beside it.
            x: Math.round(win.width / 2 - island.clockRestCentre)
            suspended: false
            quickOpen: scene.quickOpen
            onSettingsToggled: scene.toggleSettings()
            onQuickSettingsToggled: scene.toggleQuickSettings()
            onQuickCloseRequested: scene.quickOpen = false
        }
    }

    // ARCHRUUD Volume OSD: live interactive slider, independent of notifications.
    C.VolumeOSD {
        targetScreen: scene.modelData
        enabled: scene.modelData === Quickshell.screens[0]
        powerCompanionOpen: scene.powerCompanionOpen
    }

    S.SettingsWindow {
        targetScreen: scene.modelData
        open: scene.settingsOpen
        onCloseRequested: scene.settingsOpen = false
    }

    // Popup appears only on the first output, without reserving desktop space.
    // The Quickshell notification server is opt-in and conflict-aware.
    C.NotificationToasts {
        targetScreen: scene.modelData
        visible: scene.modelData === Quickshell.screens[0]
            && Notifs.status === "active" && Notifs.toasts.length > 0
    }

    // A transparent full-output layer under the bar that exists only while quick
    // settings is open, so a click anywhere off the island closes it. It is below
    // the bar (Bottom < Top), so the island still takes its own clicks, and it is
    // gone when closed, so the desktop is never blocked.
    PanelWindow {
        id: dismiss
        screen: scene.modelData
        visible: scene.quickOpen
        color: "transparent"
        anchors { top: true; bottom: true; left: true; right: true }
        exclusionMode: ExclusionMode.Ignore
        WlrLayershell.layer: WlrLayer.Bottom
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
        WlrLayershell.namespace: "archruud-kairos-original-dismiss"

        MouseArea {
            anchors.fill: parent
            acceptedButtons: Qt.LeftButton | Qt.RightButton | Qt.MiddleButton
            onPressed: scene.quickOpen = false
        }
    }
}
